@echo off
start "" pyw -3.12 "%~dp0doors_sound_radar.py"
