DOORS SOUND RADAR
=================
Passive audio overlay that listens to your speakers, recognizes DOORS
entity sounds, and shows what it is + how to survive it.
It NEVER touches the game: no memory reading, no injection.

SETUP (Windows, ~3 minutes)
  1. Install Python 3.12+ from https://www.python.org/downloads/
     (tick "Add python.exe to PATH" in the installer).
  2. In this folder, open a terminal and run:
        pip install -r requirements.txt
  3. Double-click "Start Sound Radar.bat".

FIRST RUN - TRAINING
  DOORS plays the same sound files every time, so the app just needs one
  short reference sample per entity:
  1. Launch DOORS in windowed / borderless mode (so the overlay is visible).
  2. The first time you hear e.g. Rush, click REC next to it. It captures
     4 seconds automatically (click STOP earlier to save a shorter clip).
  3. Record Screech, Eyes, Figure, Seek, Electrical, Timoth, Halt, Glitch
     over your next few games. Samples are saved in templates\ and persist.

DETECTING
  After that it alerts on its own: entity name in big colored text, the
  survival tip, and a confidence %. Ambush is reported automatically when
  Rush fires repeatedly within ~14 seconds.

TUNING
  - sensitivity slider: right = more tolerant, fewer misses, more false hits.
  - if you change your volume a lot, re-record samples.
  - drag the title bar to move the overlay; "_" collapses, "x"/Esc quits.

License: do whatever you want, credit appreciated. Not affiliated with
Roblox Corporation. Use at your own risk regarding Roblox ToS.
